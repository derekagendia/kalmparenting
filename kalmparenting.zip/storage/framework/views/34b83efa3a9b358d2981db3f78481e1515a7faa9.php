<?php $__env->startSection('content'); ?>

    <div class="pb-5 bg-dark" style="padding-top:8rem;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2 class="display-3 text-white">Our blogs</h2>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb bg-transparent">
                            <li class="breadcrumb-item text-white fw-bold "><a href="index.html">Home</a></li>
                            <li class="breadcrumb-item text-white fw-bold active" aria-current="page">Blogs</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    </section>

    <div class="container">
        <div class="row mt-5 mb-5">
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-lg-4 col-md-6">
                    <div class="card card-sm rounded-top-start rounded-bottom-end lift mt-3">
                        <!-- Image  -->
                        <img class="card-img rounded-top-start" src="<?php echo e(asset(Voyager::image($post->image))); ?>" alt="...">
                        <!-- SHAPE -->
                        <div class="position-relative">
                            <div class="shape shape-fluid-x shape-top text-white">
                                <div class="shape-img pb-4">
                                    <svg viewBox="0 0 100 50" preserveAspectRatio="none">
                                        <path d="M0 25h25L75 0h25v50H0z" fill="currentColor"></path>
                                    </svg>
                                </div>
                            </div>
                        </div>
                        <!-- Body -->
                        <div class="card-body">
                            <!-- Heading -->
                            <div class="d-flex align-items-center mb-3">
                                <h3><?php echo e($post->title); ?></h3>
                            </div>
                            <!-- Text -->
                            <small>
                                <?php echo e($post->excerpt); ?>

                            </small>
                            <p class="mt-3"><a href="<?php echo e(route('blog.detail',$post->slug)); ?>" target="_blank">
                                    <button class="btn btn-danger btn-sm">Details</button>
                                </a></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-lg-4 col-md-6">
                    <div class="item item-thumbnail">
                        <div class="item-info">
                            <p class="item-desc"> <?php echo e(__('Not data Post')); ?></p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <?php echo e($posts->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\Documents\GitHub\kalmparenting\resources\views/blog/index.blade.php ENDPATH**/ ?>